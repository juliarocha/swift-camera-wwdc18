
import UIKit
import CoreImage
import PlaygroundSupport

//Criar View
let myView = UIView(frame: CGRect(x: 0, y: 0, width: 512, height: 768))
myView.backgroundColor = .white

public var recorteNome:String
recorteNome = "recorterio"

//mudar local
func hereWeGo( nome:String) {
    var locationView = UIImageView(frame: CGRect(x: 0, y: 0, width: 512, height: 768))
    locationView.image = UIImage(named: nome)
    locationView.contentMode = .scaleAspectFit
    myView.addSubview(locationView)
    let inputCIImage = CIImage(image: UIImage(named: nome)!)
    let blurFilter = CIFilter(name: "CIDiscBlur")!
    blurFilter.setValue(inputCIImage, forKey: kCIInputImageKey)
    blurFilter.setValue(10, forKey: kCIInputRadiusKey)
    let myImage = blurFilter.outputImage!
    locationView.image = UIImage(ciImage: myImage)
    recorteNome = "recorte\(nome)"
}


//Imagem Camera
public func imageViewCamera() {
    var imageViewCam : UIImageView
    imageViewCam  = UIImageView(frame: CGRect(x: 8 , y: 31, width: 489, height: 405 ));
    imageViewCam.image = UIImage(named:"cam.png")
    imageViewCam.contentMode = .scaleAspectFit
    myView.addSubview(imageViewCam)
}


//Imagem Menina
public var imageViewA : UIImageView
imageViewA  = UIImageView(frame:CGRect(x: 260 , y: 457 , width: 240, height: 200));
imageViewA.image = UIImage(named:"menina1.png")
public func imageViewMenina() {
    imageViewA.contentMode = .scaleAspectFit
    myView.addSubview(imageViewA)
}


//Imagem Menino
public var imageViewO : UIImageView
imageViewO = UIImageView(frame:CGRect(x: 0, y: 457, width: 240, height: 200));
imageViewO.image = UIImage(named:"menino1.png")
public func imageViewMenino() {
    imageViewO.contentMode = .scaleAspectFit
    myView.addSubview(imageViewO)
}

//Fala Menina
public func textGirl( text:String) {
    let imageLabel = UIImageView(frame: CGRect(x: 261, y: 404, width: 84, height: 60))
    imageLabel.image = UIImage(named: "balao2.png")
    imageLabel.contentMode = .scaleAspectFit
    imageLabel.alpha = 0.5
    myView.addSubview(imageLabel)
    
    let girlLabel = UILabel(frame: CGRect(x: 261, y: 404, width: 80 , height: 55))
    girlLabel.textAlignment = .center
    girlLabel.numberOfLines = 0
    girlLabel.adjustsFontSizeToFitWidth = true
    girlLabel.text = text
    myView.addSubview(girlLabel)
    
}

//Fala Menino
public func textBoy( text:String) {
    let imageLabel = UIImageView(frame: CGRect(x: 167, y: 406, width: 84, height: 60))
    imageLabel.image = UIImage(named: "balao1.png")
    imageLabel.contentMode = .scaleAspectFit
    imageLabel.alpha = 0.5
    myView.addSubview(imageLabel)
    
    let boyLabel = UILabel(frame: CGRect(x: 167, y: 406, width: 80 , height: 55))
    boyLabel.textAlignment = .center
    boyLabel.numberOfLines = 0
    boyLabel.adjustsFontSizeToFitWidth = true
    boyLabel.text = text
    myView.addSubview(boyLabel)
}


//Animacao Menina
public func animarMenina(){
    var imgListArray :[UIImage] = []
    for countValue in 1...2
    {
        let strImageName : String = "menina\(countValue)"
        let image  = UIImage(named:strImageName)
        imgListArray.append(image!)
    }
    
    imageViewA.animationImages = imgListArray;
    imageViewA.animationDuration = 2
    imageViewA.animationRepeatCount = 1
    imageViewA.startAnimating()
    textGirl(text: "I'm Julia and this is Ed!")
}


//Animacao Menino
public func animarMenino() {
    var imgListArray :[UIImage] = []
    for countValue in 1...3
    {
        let strImageName : String = "menino\(countValue)"
        let image  = UIImage(named:strImageName)
        imgListArray.append(image!)
    }
    
    imageViewO.animationImages = imgListArray;
    imageViewO.animationDuration = 4
    imageViewO.animationRepeatCount = 2
    imageViewO.startAnimating()
    textBoy(text: "Hello!")
}


//Adicionar Subviews
public func viewWillLayoutSubviews() {
    hereWeGo(nome: "rio")
    imageViewCamera()
    imageViewMenino()
    imageViewMenina()
}


viewWillLayoutSubviews()
animarMenina()
animarMenino()

PlaygroundPage.current.liveView = myView


