
/*:
 # Welcome To SwiftCamera!

 ## Here you can see a little about some principles of photography.
 
 ### Use the device in the landscape mode and don't use fullscreen for a better experience!
 
 Meet Julia and Ed, her father! He is a photographer and today he will teach Julia photography!
 
 ## Join them!

 You’ll learn about light, exposure time and ISO.

 ### Go to the next page to start!
 
*/



