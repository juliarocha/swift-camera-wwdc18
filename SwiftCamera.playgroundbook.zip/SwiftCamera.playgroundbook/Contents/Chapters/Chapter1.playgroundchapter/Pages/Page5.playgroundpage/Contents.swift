//#-hidden-code
import UIKit
import CoreImage
import PlaygroundSupport
import AVFoundation
//#-end-hidden-code

/*:
# Play Time

 
Ed - "We did it! Now you know the basics about light in photography!"
 
Julia - "You can practice all you’ve learned."
 

Take your time and change the location if you want to!
There are five locations for you to choose: Rio, Italy, Netherlands, France and Switzerland!

## Tap "Run my code" once you choose the location!
 
 Wait for it do load and enjoy!
 
 Turn the volume up to hear the 'click'!
*/



//#-hidden-code
//Criar View
let myView = UIView(frame: CGRect(x: 0, y:0, width: 512, height: 768))
myView.backgroundColor = .white


//Ciclo de Imagens e Contador
public let cicloImagem = [UIImage(named: "vela"), UIImage(named: "lampada"), UIImage(named: "nuvem"), UIImage(named: "sol")]
public var n:Int = 0


var player: AVAudioPlayer?

//mudar local


public enum Place:String{
    case Rio = "rio"
    case Italy = "italy"
    case Netherlands = "netherlands"
    case France = "france"
    case Switzerland = "switzerland"
}

public var whereTo:Place = Place.Rio

public func chooseLocation(local: Place) {
    whereTo = local
}

print(whereTo.rawValue)

//#-end-hidden-code


chooseLocation(local: /*#-editable-code*/.Rio/*#-end-editable-code*/)


//#-hidden-code
public func hereWeGo() {
    var recorteNome:String
    var locationView = UIImageView(frame: CGRect(x: 0, y: 0, width: 512, height: 768))
    locationView.image = UIImage(named: whereTo.rawValue)
    locationView.contentMode = .scaleAspectFit
    myView.addSubview(locationView)
    let inputCIImage = CIImage(image: UIImage(named: whereTo.rawValue)!)
    let blurFilter = CIFilter(name: "CIDiscBlur")!
    blurFilter.setValue(inputCIImage, forKey: kCIInputImageKey)
    blurFilter.setValue(10, forKey: kCIInputRadiusKey)
    let myImage = blurFilter.outputImage!
    locationView.image = UIImage(ciImage: myImage)
    recorteNome = "recorte\(whereTo.rawValue)"
    imageViewVisor.image = UIImage(named: recorteNome)
}


//sound
func playSound() {
    guard let url = Bundle.main.url(forResource: "click", withExtension: "wav") else { return }
    
    do {
        try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
        try AVAudioSession.sharedInstance().setActive(true)
        
        /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
        player = try AVAudioPlayer(contentsOf: url, fileTypeHint: "wav")
        
        guard let player = player else { return }
        
        player.play()
        
    } catch let error {
        print(error.localizedDescription)
    }
}


//Imagem Visor
public var imageViewVisor : UIImageView
imageViewVisor  = UIImageView(frame:CGRect(x: 110 , y: 173, width: 347, height: 194));
imageViewVisor.image = UIImage(named: "recorte\(whereTo.rawValue)")


//Imagem Click
public var imageViewClick : UIImageView
imageViewClick = UIImageView(frame:CGRect(x: 110 , y: 173, width: 347, height: 194));
imageViewClick.image = UIImage(named: "recorte\(whereTo.rawValue)")
public var imageViewBetween : UIImageView
imageViewBetween = UIImageView(frame:CGRect(x: 110 , y: 173, width: 347, height: 194));
imageViewBetween.image = UIImage(named: "betweenClick")


//Slider Exposure
public let exposureSlider = UISlider(frame: CGRect (x: 28 , y: 261 , width: 74, height: 29))


//Slider iso
public let isoSlider = UISlider(frame: CGRect (x: 28 , y: 324, width: 74, height: 29))


//button
public let buttonClick = UIButton(frame: CGRect(x: 350, y: 65, width: 170, height: 89))


//Imagem Luz
public var imageViewLuz : UIImageView
imageViewLuz  = UIImageView(frame:CGRect(x: 28 , y: 173 , width: 74, height: 66 ));
imageViewLuz.image = UIImage(named:"vela.png")


//Aplicacao de filtros
public func applyFilter(nome:String, in image:UIImage, potencia:Double) {
    let inputImage = image
    let context = CIContext(options: nil)
    if let currentFilter = CIFilter(name: nome) {
        let beginImage = CIImage(image: inputImage)
        currentFilter.setValue(beginImage, forKey: kCIInputImageKey)
        if nome == "CIExposureAdjust" {
            currentFilter.setValue(potencia, forKey: kCIInputEVKey)
        }
        if nome == "CIGammaAdjust" {
            currentFilter.setValue(potencia, forKey: "inputPower")
        }
        if let output = currentFilter.outputImage {
            if let cgimg = context.createCGImage(output, from: output.extent) {
                let processedImage = UIImage(cgImage: cgimg)
                // do something interesting with the processed image
                imageViewVisor.image = processedImage
                imageViewClick.image = processedImage
            }
        }
    }
}


//Gestos
public class Gestos {
    
    
    //Troca Luz
    @objc public func trocaImagem( gesture: UITapGestureRecognizer) {
        n = n + 1
        if n > cicloImagem.count - 1 {
            n = 0
        }
        imageViewLuz.image = cicloImagem[n]
        
        //Efeito Visor
        if imageViewLuz.image == cicloImagem[0] {
            imageViewVisor.image = UIImage(named: "recorte\(whereTo.rawValue)")
            imageViewClick.image = UIImage(named: "recorte\(whereTo.rawValue)")
        }
        
        if imageViewLuz.image == cicloImagem[1] {
            imageViewVisor.image = UIImage(named: "recorte\(whereTo.rawValue)")
            applyFilter(nome: "CIExposureAdjust", in: imageViewVisor.image!, potencia: 0.5)
            imageViewClick.image = UIImage(named: "recorte\(whereTo.rawValue)")
            applyFilter(nome: "CIExposureAdjust", in: imageViewClick.image!, potencia: 0.5)
        }
        if imageViewLuz.image == cicloImagem[2] {
            imageViewVisor.image = UIImage(named: "recorte\(whereTo.rawValue)")
            applyFilter(nome: "CIExposureAdjust", in: imageViewVisor.image!, potencia: 0.7)
            imageViewClick.image = UIImage(named: "recorte\(whereTo.rawValue)")
            applyFilter(nome: "CIExposureAdjust", in: imageViewClick.image!, potencia: 0.7)
        }
        if imageViewLuz.image == cicloImagem[3] {
            imageViewVisor.image = UIImage(named: "recorte\(whereTo.rawValue)")
            applyFilter(nome: "CIExposureAdjust", in: imageViewVisor.image!, potencia: 1.0)
            imageViewClick.image = UIImage(named: "recorte\(whereTo.rawValue)")
            applyFilter(nome: "CIExposureAdjust", in: imageViewClick.image!, potencia: 1.0)
        }
    }
}

let gestos = Gestos()
public let tap = UITapGestureRecognizer(target: gestos, action: #selector(Gestos.trocaImagem(gesture:)))


public class Acting {
    
    
    //Funcao Slider Exposure
    @objc public func sliderExposure( sender: UISlider) {
        let sliderValue = sender.value
        imageViewVisor.image = UIImage(named: "recorte\(whereTo.rawValue)")
        imageViewClick.image = UIImage(named: "recorte\(whereTo.rawValue)")
        if imageViewLuz.image == cicloImagem[1] {
            sender.minimumValue = 0.4
        }
        if imageViewLuz.image == cicloImagem[2] {
            sender.minimumValue = 0.6
        }
        if imageViewLuz.image == cicloImagem[3] {
            sender.minimumValue = 0.8
        }
        applyFilter(nome: "CIExposureAdjust", in: imageViewVisor.image!, potencia: Double(sliderValue))
        applyFilter(nome: "CIExposureAdjust", in: imageViewClick.image!, potencia: Double(sliderValue))
        
        
    }
    
    //Funcao Slider ISO
    @objc public func sliderISO( sender: UISlider) {
        let sliderValue = sender.value
        sender.minimumValue = 0.5
        imageViewVisor.image = UIImage(named: "recorte\(whereTo.rawValue)")
        imageViewClick.image = UIImage(named: "recorte\(whereTo.rawValue)")
        applyFilter(nome: "CIGammaAdjust", in: imageViewVisor.image!, potencia: Double(sliderValue))
        applyFilter(nome: "CIGammaAdjust", in: imageViewClick.image!, potencia: Double(sliderValue))
    }
    
    //Funcao Click
    @objc public func click( sender: UIButton) {
        playSound()
        UIView.animate(withDuration: 0.5, animations: {
            UIView.animate(withDuration: 0.005, animations: {
                imageViewBetween.alpha = 0.5
            }) { (sucess) in
                UIView.animate(withDuration: 0.005, animations: {
                    imageViewBetween.alpha = 0.0
                })
            }
            imageViewClick.alpha = 1.0
        }) { (sucess) in
            UIView.animate(withDuration: 4, animations: {
                imageViewClick.alpha = 0.0
            })
        }
    }
    
}

let acting = Acting()

public func setSlider1() {
    exposureSlider.minimumValue = 0
    exposureSlider.maximumValue = 1.0
    exposureSlider.isContinuous = true
    exposureSlider.tintColor = UIColor.black
    exposureSlider.thumbTintColor = UIColor.red
    exposureSlider.value = 0.5
    exposureSlider.isUserInteractionEnabled = true
    myView.addSubview(exposureSlider)
    exposureSlider.addTarget(acting, action: #selector(Acting.sliderExposure(sender:)), for: .valueChanged)
    let slider1label = UILabel(frame: CGRect(x: 39, y: 287, width: 52 , height: 25))
    slider1label.textAlignment = .center
    slider1label.adjustsFontSizeToFitWidth = true
    slider1label.text = "Exposure"
    myView.addSubview(slider1label)
}


public func setSlider2() {
    isoSlider.minimumValue = 0
    isoSlider.maximumValue = 1.0
    isoSlider.isContinuous = true
    isoSlider.tintColor = UIColor.black
    isoSlider.thumbTintColor = UIColor.blue
    isoSlider.value = 0.5
    isoSlider.isUserInteractionEnabled = true
    myView.addSubview(isoSlider)
    isoSlider.addTarget(acting, action: #selector(Acting.sliderISO(sender:)), for: .valueChanged)
    let slider2label = UILabel(frame: CGRect(x: 51, y: 354, width: 31 , height: 16))
    slider2label.textAlignment = .center
    slider2label.adjustsFontSizeToFitWidth = false
    slider2label.text = "ISO"
    myView.addSubview(slider2label)
}


//Botao Click
public func button() {
    let image = UIImage(named: "buttonClick.png")
    buttonClick.setImage(image, for: UIControlState.normal)
    buttonClick.isUserInteractionEnabled = true
    buttonClick.addTarget(acting, action: #selector(Acting.click(sender:)), for: .touchUpInside )
    myView.addSubview(buttonClick)
}


//ImageView Visor
public func imageVisor() {
    imageViewVisor.contentMode = .scaleAspectFit
    myView.addSubview(imageViewVisor)
}


//ImageView Luz
public func imageLuz() {
    imageViewLuz.contentMode = .scaleAspectFit
    imageViewLuz.isUserInteractionEnabled = true
    imageViewLuz.addGestureRecognizer(tap)
    myView.addSubview(imageViewLuz)
}


//Imagem Camera
public func imageCamera2() {
    var imageViewCam2 : UIImageView
    imageViewCam2  = UIImageView(frame:CGRect(x: 8 , y: 31, width: 489, height: 405 ));
    imageViewCam2.image = UIImage(named:"cam2.png")
    imageViewCam2.contentMode = .scaleAspectFit
    myView.addSubview(imageViewCam2)
}


//Imagem Menina
public var imageViewA : UIImageView
imageViewA  = UIImageView(frame:CGRect(x: 260 , y: 457 , width: 240, height: 200));
imageViewA.image = UIImage(named:"menina1.png")
public func imageViewMenina() {
    imageViewA.contentMode = .scaleAspectFit
    myView.addSubview(imageViewA)
}


//Imagem Menino
public var imageViewO : UIImageView
imageViewO = UIImageView(frame:CGRect(x: 0, y: 457, width: 240, height: 200));
imageViewO.image = UIImage(named:"menino1.png")
public func imageViewMenino() {
    imageViewO.contentMode = .scaleAspectFit
    myView.addSubview(imageViewO)
}

//Fala Menina
public func textGirl( text:String) {
    let imageLabel = UIImageView(frame: CGRect(x: 261, y: 404, width: 84, height: 60))
    imageLabel.image = UIImage(named: "balao2.png")
    imageLabel.contentMode = .scaleAspectFit
    imageLabel.alpha = 0.5
    myView.addSubview(imageLabel)
    
    let girlLabel = UILabel(frame: CGRect(x: 261, y: 404, width: 80 , height: 55))
    girlLabel.textAlignment = .center
    girlLabel.numberOfLines = 0
    girlLabel.adjustsFontSizeToFitWidth = true
    girlLabel.text = text
    myView.addSubview(girlLabel)
    
}

//Fala Menino
public func textBoy( text:String) {
    let imageLabel = UIImageView(frame: CGRect(x: 167, y: 404, width: 84, height: 60))
    imageLabel.image = UIImage(named: "balao1.png")
    imageLabel.contentMode = .scaleAspectFit
    imageLabel.alpha = 0.5
    myView.addSubview(imageLabel)
    
    let boyLabel = UILabel(frame: CGRect(x: 172, y: 406, width: 80 , height: 55))
    boyLabel.textAlignment = .center
    boyLabel.numberOfLines = 0
    boyLabel.adjustsFontSizeToFitWidth = true
    boyLabel.text = text
    myView.addSubview(boyLabel)
}


//Animacao Menina
public func animarMenina(){
    var imgListArray :[UIImage] = []
    for countValue in 1...2
    {
        let strImageName : String = "menina\(countValue)"
        let image  = UIImage(named:strImageName)
        imgListArray.append(image!)
    }
    
    imageViewA.animationImages = imgListArray;
    imageViewA.animationDuration = 3
    imageViewA.animationRepeatCount = 2
    imageViewA.startAnimating()
    textGirl(text: "Tap on the top  right button!")
}

//Animacao Menino
public func animarMenino() {
    var imgListArray :[UIImage] = []
    for countValue in 1...3
    {
        let strImageName : String = "menino\(countValue)"
        let image  = UIImage(named:strImageName)
        imgListArray.append(image!)
    }
    
    imageViewO.animationImages = imgListArray;
    imageViewO.animationDuration = 4
    imageViewO.animationRepeatCount = 2
    imageViewO.startAnimating()
    textBoy(text: "Take your picture!")
}


//ImageView Click
public func imageClick() {
    imageViewClick.contentMode = .scaleAspectFit
    imageViewClick.alpha = 0.0
    myView.addSubview(imageViewClick)
}



public func imageBetween() {
    imageViewBetween.contentMode = .scaleAspectFit
    imageViewBetween.alpha = 0.0
    myView.addSubview(imageViewBetween)
}

public func imageCameraOL() {
    var imageViewCamOL : UIImageView
    imageViewCamOL  = UIImageView(frame: CGRect(x: 8 , y: 31, width: 489, height: 405 ));
    imageViewCamOL.image = UIImage(named:"camOverlay.png")
    imageViewCamOL.contentMode = .scaleAspectFit
    myView.addSubview(imageViewCamOL)
}


hereWeGo()

//Adicionar Subviews
public func viewWillLayoutSubviews() {
    imageVisor()
    imageCamera2()
    imageClick()
    imageBetween()
    imageCameraOL()
    imageLuz()
    imageViewMenino()
    imageViewMenina()
    setSlider1()
    setSlider2()
    button()
}


viewWillLayoutSubviews()

animarMenino()
animarMenina()
PlaygroundPage.current.liveView = myView

//#-end-hidden-code

