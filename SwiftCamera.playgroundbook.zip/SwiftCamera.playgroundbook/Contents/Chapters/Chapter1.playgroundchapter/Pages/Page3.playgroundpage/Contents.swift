
/*:
# Exposure Time

Ed - "Now that you understand the types of light, you should think about how much time the camera will capture this light!"

The camera is very fast, so, it uses only fractions of a second to take the photo.
 
This time means how long the camera will be able to absorb that light.

Ed - "But pay attention, if the exposure time is too long, the photo will be too bright!"

Julia - "Try it out!"
*/

