
import UIKit
import CoreImage
import PlaygroundSupport

//Criar View
let myView = UIView(frame: CGRect(x: 0, y:0, width: 512, height: 768))
myView.backgroundColor = .white


//Ciclo de Imagens e Contador
public let cicloImagem = [UIImage(named: "vela"), UIImage(named: "lampada"), UIImage(named: "nuvem"), UIImage(named: "sol")]
public var n:Int = 0



public var recorteNome:String
recorteNome = "recorterio"


//Imagem Visor
public var imageViewVisor : UIImageView
imageViewVisor  = UIImageView(frame:CGRect(x: 110 , y: 173, width: 347, height: 194));
imageViewVisor.image = UIImage(named: recorteNome)


//mudar local
func hereWeGo( nome:String) {
    var locationView = UIImageView(frame: CGRect(x: 0, y:0, width: 512, height: 768))
    locationView.image = UIImage(named: nome)
    locationView.contentMode = .scaleAspectFit
    myView.addSubview(locationView)
    let inputCIImage = CIImage(image: UIImage(named: nome)!)
    let blurFilter = CIFilter(name: "CIDiscBlur")!
    blurFilter.setValue(inputCIImage, forKey: kCIInputImageKey)
    blurFilter.setValue(10, forKey: kCIInputRadiusKey)
    let myImage = blurFilter.outputImage!
    locationView.image = UIImage(ciImage: myImage)
    recorteNome = "recorte\(nome)"
    imageViewVisor.image = UIImage(named: recorteNome)
}



//Slider Exposure
public let exposureSlider = UISlider(frame: CGRect (x: 28 , y: 261 , width: 74, height: 29))


//Imagem Luz
public var imageViewLuz : UIImageView
imageViewLuz  = UIImageView(frame:CGRect(x: 28 , y: 173 , width: 74, height: 66 ));
imageViewLuz.image = UIImage(named:"vela.png")


//Aplicacao de filtros
public func applyFilter(nome:String, in image:UIImage, potencia:Double) {
    let inputImage = image
    let context = CIContext(options: nil)
    if let currentFilter = CIFilter(name: nome) {
        let beginImage = CIImage(image: inputImage)
        currentFilter.setValue(beginImage, forKey: kCIInputImageKey)
        if nome == "CIExposureAdjust" {
            currentFilter.setValue(potencia, forKey: kCIInputEVKey)
        }
        if nome == "CIGammaAdjust" {
            currentFilter.setValue(potencia, forKey: "inputPower")
        }
        if let output = currentFilter.outputImage {
            if let cgimg = context.createCGImage(output, from: output.extent) {
                let processedImage = UIImage(cgImage: cgimg)
                // do something interesting with the processed image
                imageViewVisor.image = processedImage
            }
        }
    }
}


//Gestos
public class Gestos {
    
    
    //Troca Luz
    @objc public func trocaImagem( gesture: UITapGestureRecognizer) {
        n = n + 1
        if n > cicloImagem.count - 1 {
            n = 0
        }
        imageViewLuz.image = cicloImagem[n]
        
        //Efeito Visor
        if imageViewLuz.image == cicloImagem[0] {
            imageViewVisor.image = UIImage(named: "recorterio")
        }
        
        if imageViewLuz.image == cicloImagem[1] {
            imageViewVisor.image = UIImage(named: "recorterio")
            applyFilter(nome: "CIExposureAdjust", in: imageViewVisor.image!, potencia: 0.5)
        }
        if imageViewLuz.image == cicloImagem[2] {
            imageViewVisor.image = UIImage(named: "recorterio")
            applyFilter(nome: "CIExposureAdjust", in: imageViewVisor.image!, potencia: 0.7)
        }
        if imageViewLuz.image == cicloImagem[3] {
            imageViewVisor.image = UIImage(named: "recorterio")
            applyFilter(nome: "CIExposureAdjust", in: imageViewVisor.image!, potencia: 1.0)
        }
    }
}

let gestos = Gestos()
public let tap = UITapGestureRecognizer(target: gestos, action: #selector(Gestos.trocaImagem(gesture:)))


public class Sliders {
    
    
    //Funcao Slider Exposure
    @objc public func sliderExposure( sender: UISlider) {
        let sliderValue = sender.value
        imageViewVisor.image = UIImage(named: "recorterio")
        if imageViewLuz.image == cicloImagem[1] {
            sender.minimumValue = 0.4
        }
        if imageViewLuz.image == cicloImagem[2] {
            sender.minimumValue = 0.6
        }
        if imageViewLuz.image == cicloImagem[3] {
            sender.minimumValue = 0.8
        }
        applyFilter(nome: "CIExposureAdjust", in: imageViewVisor.image!, potencia: Double(sliderValue))
    }
    
    
}

let sliders = Sliders()

public func setSlider1() {
    exposureSlider.minimumValue = 0
    exposureSlider.maximumValue = 1.0
    exposureSlider.isContinuous = true
    exposureSlider.tintColor = UIColor.black
    exposureSlider.thumbTintColor = UIColor.red
    exposureSlider.value = 0.5
    exposureSlider.isUserInteractionEnabled = true
    myView.addSubview(exposureSlider)
    exposureSlider.addTarget(sliders, action: #selector(Sliders.sliderExposure(sender:)), for: .valueChanged)
    let slider1label = UILabel(frame: CGRect(x: 39, y: 287, width: 52 , height: 25))
    slider1label.textAlignment = .center
    slider1label.adjustsFontSizeToFitWidth = true
    slider1label.text = "Exposure"
    myView.addSubview(slider1label)
}


//ImageView Visor
public func imageVisor() {
    imageViewVisor.contentMode = .scaleAspectFit
    myView.addSubview(imageViewVisor)
}


//ImageView Luz
public func imageLuz() {
    imageViewLuz.contentMode = .scaleAspectFit
    imageViewLuz.isUserInteractionEnabled = true
    imageViewLuz.addGestureRecognizer(tap)
    myView.addSubview(imageViewLuz)
}


//Imagem Camera
public func imageCamera2() {
    var imageViewCam2 : UIImageView
    imageViewCam2  = UIImageView(frame:CGRect(x: 8 , y: 31, width: 489, height: 405 ));
    imageViewCam2.image = UIImage(named:"cam2.png")
    imageViewCam2.contentMode = .scaleAspectFit
    myView.addSubview(imageViewCam2)
}


//Imagem Menina
public var imageViewA : UIImageView
imageViewA  = UIImageView(frame:CGRect(x: 260 , y: 457 , width: 240, height: 200));
imageViewA.image = UIImage(named:"menina1.png")
public func imageViewMenina() {
    imageViewA.contentMode = .scaleAspectFit
    myView.addSubview(imageViewA)
}


//Imagem Menino
public var imageViewO : UIImageView
imageViewO = UIImageView(frame:CGRect(x: 0, y: 457, width: 240, height: 200));
imageViewO.image = UIImage(named:"menino1.png")
public func imageViewMenino() {
    imageViewO.contentMode = .scaleAspectFit
    myView.addSubview(imageViewO)
}

//Fala Menina
public func textGirl( text:String) {
    let imageLabel = UIImageView(frame: CGRect(x: 261, y: 406, width: 84, height: 60))
    imageLabel.image = UIImage(named: "balao2.png")
    imageLabel.contentMode = .scaleAspectFit
    imageLabel.alpha = 0.5
    myView.addSubview(imageLabel)
    
    let girlLabel = UILabel(frame: CGRect(x: 258, y: 406, width: 80 , height: 55))
    girlLabel.textAlignment = .center
    girlLabel.numberOfLines = 0
    girlLabel.adjustsFontSizeToFitWidth = true
    girlLabel.text = text
    myView.addSubview(girlLabel)
    
}

//Fala Menino
public func textBoy( text:String) {
    let imageLabel = UIImageView(frame: CGRect(x: 167, y: 406, width: 84, height: 60))
    imageLabel.image = UIImage(named: "balao1.png")
    imageLabel.contentMode = .scaleAspectFit
    imageLabel.alpha = 0.5
    myView.addSubview(imageLabel)
    
    let boyLabel = UILabel(frame: CGRect(x: 173, y: 406, width: 80 , height: 55))
    boyLabel.textAlignment = .center
    boyLabel.numberOfLines = 0
    boyLabel.adjustsFontSizeToFitWidth = true
    boyLabel.text = text
    myView.addSubview(boyLabel)
    
}


//Animacao Menina
public func animarMenina(){
    var imgListArray :[UIImage] = []
    for countValue in 1...2
    {
        let strImageName : String = "menina\(countValue)"
        let image  = UIImage(named:strImageName)
        imgListArray.append(image!)
    }
    
    imageViewA.animationImages = imgListArray;
    imageViewA.animationDuration = 2
    imageViewA.animationRepeatCount = 1
    imageViewA.startAnimating()
    textGirl(text: "Try out the exposure slider!")
}


//Animacao Menino
public func animarMenino() {
    var imgListArray :[UIImage] = []
    for countValue in 1...3
    {
        let strImageName : String = "menino\(countValue)"
        let image  = UIImage(named:strImageName)
        imgListArray.append(image!)
    }
    
    imageViewO.animationImages = imgListArray;
    imageViewO.animationDuration = 4
    imageViewO.animationRepeatCount = 2
    imageViewO.startAnimating()
    textBoy(text: "Change light in the camera.")
}



//Adicionar Subviews
public func viewWillLayoutSubviews() {
    hereWeGo(nome: "rio")
    imageVisor()
    imageCamera2()
    imageLuz()
    imageViewMenino()
    imageViewMenina()
    setSlider1()
}


viewWillLayoutSubviews()

animarMenino()
animarMenina()

PlaygroundPage.current.liveView = myView

