
/*:
# ISO

Ed - "We are almost done, just one more thing!"

ISO is the sensitivity of the camera. It means how much light the camera is able to absorb.
So, it works in a balance with Exposure Time.
 
If the Exposure Time is too long and the ISO is too high, the photo will be too bright because the camera will capture too much light.
And if the Exposure Time is too short and the ISO is too low, the photo will be too dark because the camera won't capture enough light.
 
Ed - "Think about balance and go for it!"

Julia - "Let's try!"
*/

