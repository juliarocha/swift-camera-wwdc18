
/*:
# Light

Ed - "One of the most important concepts in photography is light! If the lighting is not enough, the photo will be very dark…"

Julia - "Change the lighting to see how it affects the photo!"

### The candle:
 
 Represents a low light, usually found in indoor spaces where natural light can’t reach.
 
### The lightbulb:
 
 Represents a artificial light, like indoor spaces that have a good lighting.
 
### The cloud:
 
 Represents a cloudy day, such as a outdoor space but no direct light from the sun.
 
### The sun:
 
 Represents a sunny day, as a outdoor space with a direct light from the sun.
*/

